//<DOM Manipulation>
//<Random Number Generation>
//<Function Declaration>
//<setInterval Method>
//<Event Handling>
//<Conditional Statements>
//<Updating Element Values>