//<DOM Manipulation>
//<Event Handling>
//<Arrow Functions>
//<Error Handling>
//<Attributes Manipulation>
//<Updating Element Values>