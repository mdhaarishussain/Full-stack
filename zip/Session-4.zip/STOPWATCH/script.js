//<Variable Declaration>
//<DOM Manipulation>
//<Event Handling>
//<Arrow Functions>
//<setInterval Method>
//<Conditional Statements>
//<Updating Element Values>