//<DOM Manipulation>
//<Function Declaration>
//<Array Methods>
//<Event Handling>
//<Conditional Statements>
//<Random Number Generation>
//<Updating Element Values>