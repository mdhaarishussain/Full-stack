//<Array Methods>
//<DOM Manipulation>
//<Event Handling>
//<Function Declaration>
//<Conditional Statements>
//<setTimeout Method>
//<Data Attributes>
