// console.log("Assalamwalaikum");
// const { subMe, addMe } = require("./math.js");
// console.log(subMe);
// console.log(math);
// console.log(math.addMe(2, 5));
// console.log(math.subMe(7, 5));
const math = require('http');
console.log(math);