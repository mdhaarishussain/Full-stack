//WE WILL LEARN:
//Arrays and Basic Operations
//Array sorting
//String Manipulation
//Conditional Logic

