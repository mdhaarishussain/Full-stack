//WE WILL LEARN:
//Event Handling with addEventListener:
//DOM Manipulation:
//Asynchronous Programming with Timers:
//Enabling/Disabling Buttons Dynamically
//String Interpolation (Template Literals)
//Event Loop and Callbacks: